CC0-1.0, CC-BY-SA-4.0, CC-BY-4.0: synthetic fixture only
